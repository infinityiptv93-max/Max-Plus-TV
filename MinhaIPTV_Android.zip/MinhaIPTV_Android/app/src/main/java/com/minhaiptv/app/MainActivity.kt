package com.minhaiptv.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.weight
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.LiveTv
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Red = Color(0xFFF20D19)
private val Background = Color(0xFF090909)
private val Panel = Color(0xFF151719)
private val Muted = Color(0xFF9CA0A5)

private data class Channel(
    val number: String,
    val name: String,
    val subtitle: String
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(
                colorScheme = darkColorScheme(
                    primary = Red,
                    background = Background,
                    surface = Panel,
                    onPrimary = Color.White,
                    onBackground = Color.White,
                    onSurface = Color.White
                )
            ) {
                MinhaIPTVApp()
            }
        }
    }
}

@Composable
private fun MinhaIPTVApp() {
    var selectedTab by remember { mutableStateOf("TV") }
    var selectedChannel by remember { mutableIntStateOf(0) }
    var notice by remember { mutableStateOf("Bem-vindo ao Max Plus TV") }

    val tabs = listOf("TV", "Jogos", "Destaques", "Filmes", "Séries", "Kids", "Anime", "Explorar")
    val channels = listOf(
        Channel("001", "Canal de Notícias", "Jornal ao vivo"),
        Channel("002", "Canal Esportivo", "Esportes"),
        Channel("003", "Canal de Cinema", "Filmes"),
        Channel("004", "Canal de Variedades", "Entretenimento"),
        Channel("005", "Canal Infantil", "Programação infantil"),
        Channel("006", "Canal Musical", "Música e shows"),
        Channel("007", "Documentários", "Conhecimento"),
        Channel("008", "Notícias 24h", "Atualidades")
    )
    val categories = listOf("TV AO VIVO", "FILMES", "SÉRIES", "KIDS", "ANIME", "EXPLORAR")

    Surface(modifier = Modifier.fillMaxSize(), color = Background) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        listOf(Color(0xFF260407), Background, Background)
                    )
                )
                .padding(horizontal = 12.dp, vertical = 8.dp)
        ) {
            Header(
                tabs = tabs,
                selectedTab = selectedTab,
                onTabSelected = {
                    selectedTab = it
                    notice = "Seção: $it"
                },
                onSearch = { notice = "Pesquisa será implementada" },
                onSettings = { notice = "Configurações serão implementadas" }
            )

            Spacer(Modifier.height(8.dp))

            BoxWithConstraints(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
            ) {
                if (maxWidth >= 700.dp) {
                    Row(
                        modifier = Modifier.fillMaxSize(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        ChannelSidebar(
                            channels = channels,
                            selectedChannel = selectedChannel,
                            onChannelSelected = { index, channel ->
                                selectedChannel = index
                                notice = "Selecionado: ${channel.name}"
                            },
                            modifier = Modifier
                                .widthIn(min = 190.dp, max = 270.dp)
                                .fillMaxHeight()
                        )
                        FeatureContent(
                            categories = categories,
                            onCategorySelected = {
                                selectedTab = it
                                notice = "Categoria: $it"
                            },
                            onWatch = { notice = "Conecte uma fonte autorizada para assistir" },
                            modifier = Modifier
                                .weight(1f)
                                .fillMaxHeight()
                        )
                    }
                } else {
                    Column(modifier = Modifier.fillMaxSize()) {
                        FeatureContent(
                            categories = categories,
                            onCategorySelected = {
                                selectedTab = it
                                notice = "Categoria: $it"
                            },
                            onWatch = { notice = "Conecte uma fonte autorizada para assistir" },
                            modifier = Modifier
                                .weight(1f)
                                .fillMaxWidth()
                        )
                        Spacer(Modifier.height(8.dp))
                        ChannelCarousel(
                            channels = channels,
                            selectedChannel = selectedChannel,
                            onChannelSelected = { index, channel ->
                                selectedChannel = index
                                notice = "Selecionado: ${channel.name}"
                            }
                        )
                    }
                }
            }

            Text(
                text = notice,
                color = Muted,
                fontSize = 11.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 5.dp, start = 3.dp)
            )
        }
    }
}

@Composable
private fun Header(
    tabs: List<String>,
    selectedTab: String,
    onTabSelected: (String) -> Unit,
    onSearch: () -> Unit,
    onSettings: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .height(60.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = "▶ MAX PLUS TV",
            color = Red,
            fontSize = 19.sp,
            fontWeight = FontWeight.Black,
            maxLines = 1
        )
        Spacer(Modifier.width(12.dp))
        Row(
            modifier = Modifier
                .weight(1f)
                .horizontalScroll(rememberScrollState()),
            verticalAlignment = Alignment.CenterVertically
        ) {
            tabs.forEach { tab ->
                val active = selectedTab == tab
                Text(
                    text = tab,
                    color = Color.White,
                    fontWeight = if (active) FontWeight.Bold else FontWeight.Normal,
                    fontSize = 12.sp,
                    modifier = Modifier
                        .padding(end = 5.dp)
                        .clip(RoundedCornerShape(9.dp))
                        .background(if (active) Red else Color.Transparent)
                        .clickable { onTabSelected(tab) }
                        .padding(horizontal = 10.dp, vertical = 12.dp)
                )
            }
        }
        IconButton(onClick = onSearch) {
            Icon(Icons.Default.Search, contentDescription = "Pesquisar", tint = Color.White)
        }
        IconButton(onClick = onSettings) {
            Icon(Icons.Default.Settings, contentDescription = "Configurações", tint = Color.White)
        }
    }
}

@Composable
private fun ChannelSidebar(
    channels: List<Channel>,
    selectedChannel: Int,
    onChannelSelected: (Int, Channel) -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(12.dp))
            .background(Color(0xFF101214))
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(Color(0xFF30090D))
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(Icons.Default.LiveTv, contentDescription = null, tint = Red)
            Spacer(Modifier.width(8.dp))
            Text("Lista de Canais", fontWeight = FontWeight.Bold, fontSize = 14.sp)
        }
        LazyColumn(
            contentPadding = PaddingValues(7.dp),
            verticalArrangement = Arrangement.spacedBy(5.dp)
        ) {
            itemsIndexed(channels) { index, channel ->
                ChannelRow(
                    channel = channel,
                    selected = index == selectedChannel,
                    onClick = { onChannelSelected(index, channel) }
                )
            }
        }
    }
}

@Composable
private fun ChannelCarousel(
    channels: List<Channel>,
    selectedChannel: Int,
    onChannelSelected: (Int, Channel) -> Unit
) {
    Column {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.LiveTv, contentDescription = null, tint = Red)
            Spacer(Modifier.width(6.dp))
            Text("Canais", fontWeight = FontWeight.Bold, fontSize = 14.sp)
        }
        Spacer(Modifier.height(6.dp))
        LazyRow(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
            itemsIndexed(channels) { index, channel ->
                Row(
                    modifier = Modifier
                        .widthIn(min = 190.dp, max = 235.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(if (index == selectedChannel) Red else Panel)
                        .clickable { onChannelSelected(index, channel) }
                        .padding(10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(channel.number, fontSize = 11.sp)
                    Spacer(Modifier.width(8.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(channel.name, fontSize = 12.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(channel.subtitle, color = Color.LightGray, fontSize = 10.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                }
            }
        }
    }
}

@Composable
private fun ChannelRow(
    channel: Channel,
    selected: Boolean,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(8.dp))
            .background(if (selected) Red else Panel)
            .clickable(onClick = onClick)
            .padding(10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(channel.number, color = Color.White, fontSize = 11.sp)
        Spacer(Modifier.width(8.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(channel.name, fontSize = 12.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(channel.subtitle, color = Color.LightGray, fontSize = 10.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        Icon(Icons.Default.ChevronRight, contentDescription = null, tint = Color.LightGray)
    }
}

@Composable
private fun FeatureContent(
    categories: List<String>,
    onCategorySelected: (String) -> Unit,
    onWatch: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .verticalScroll(rememberScrollState())
            .padding(bottom = 4.dp)
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .heightIn(min = 210.dp, max = 290.dp)
                .clip(RoundedCornerShape(15.dp))
                .background(
                    Brush.linearGradient(
                        listOf(Color(0xFF071A2A), Color(0xFF28080D), Color(0xFF640A14))
                    )
                ),
            contentAlignment = Alignment.CenterStart
        ) {
            Column(modifier = Modifier.padding(24.dp)) {
                Text("MAX PLUS TV", color = Red, fontWeight = FontWeight.Black, letterSpacing = 3.sp)
                Spacer(Modifier.height(10.dp))
                Text("Seu entretenimento.", fontSize = 25.sp, fontWeight = FontWeight.Black)
                Text("Canais, filmes e séries em um só lugar.", fontSize = 13.sp, color = Color.LightGray)
                Spacer(Modifier.height(16.dp))
                Button(
                    onClick = onWatch,
                    colors = ButtonDefaults.buttonColors(containerColor = Red)
                ) {
                    Icon(Icons.Default.PlayArrow, contentDescription = null)
                    Spacer(Modifier.width(5.dp))
                    Text("Assistir agora")
                }
            }
        }

        Spacer(Modifier.height(14.dp))
        Text("Explore as categorias", fontSize = 18.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))

        val categoryColors = listOf(
            Color(0xFF8D1019), Color(0xFF075BA7), Color(0xFF6D1598),
            Color(0xFF167B28), Color(0xFFB74D0A), Color(0xFF292D32)
        )
        categories.chunked(3).forEachIndexed { rowIndex, group ->
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                group.forEachIndexed { itemIndex, category ->
                    val colorIndex = rowIndex * 3 + itemIndex
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .height(90.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(categoryColors[colorIndex % categoryColors.size])
                            .clickable { onCategorySelected(category) }
                            .padding(10.dp),
                        contentAlignment = Alignment.BottomStart
                    ) {
                        Text(category, fontSize = 12.sp, fontWeight = FontWeight.Black)
                    }
                }
                repeat(3 - group.size) {
                    Spacer(Modifier.weight(1f))
                }
            }
            if (rowIndex < categories.chunked(3).lastIndex) {
                Spacer(Modifier.height(8.dp))
            }
        }
    }
}
