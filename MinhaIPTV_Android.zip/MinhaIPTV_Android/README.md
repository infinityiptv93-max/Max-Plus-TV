# Max Plus TV — protótipo Android

Protótipo nativo em Kotlin + Jetpack Compose, com interface escura em vermelho/preto, categorias e canais demonstrativos.

## Importar no AndroidIDE
1. Baixe e extraia o ZIP.
2. No AndroidIDE, abra/importa a pasta `MinhaIPTV_Android` — a pasta correta é a que contém `settings.gradle.kts`.
3. Aguarde a sincronização do Gradle e aceite a instalação do Android SDK 35, se solicitado.
4. Execute o app pelo botão Run.

É necessário internet durante a primeira sincronização para baixar Gradle e dependências. O app ainda não reproduz vídeo nem importa listas M3U; os canais e categorias são apenas demonstração. Use somente fontes e conteúdo que você tenha autorização para acessar.
